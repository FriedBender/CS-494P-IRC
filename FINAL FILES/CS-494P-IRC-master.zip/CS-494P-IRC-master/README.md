# CS 494P Term Project

### Members
- Maksim Semchuk
- Taishawn Fontleroy
- Brandon Altermatt
